export 'package:peliculas_app/widgets/castin_card.dart';

export 'package:peliculas_app/widgets/movie_slider.dart';

export 'package:peliculas_app/widgets/CardSwiper.dart';
