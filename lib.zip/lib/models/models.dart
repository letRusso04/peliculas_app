export 'package:peliculas_app/models/movies.dart';
export 'package:peliculas_app/models/now_playing_response.dart';
