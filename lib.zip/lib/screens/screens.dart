export 'package:peliculas_app/screens/details_screen.dart';
export 'package:peliculas_app/screens/home_screen.dart';
